---
id: runbook-<slug>
title: <Titolo Runbook>
summary: <Sintesi breve (1-2 frasi)>
owner: team-platform
status: draft
tags: [runbook, ops, language/it]
created: 'YYYY-MM-DD'
updated: 'YYYY-MM-DD'

llm:
  include: true
  chunk_hint: 5000---

# <Titolo Runbook>

## Obiettivo
<Cosa risolve / perché esiste>

## Prerequisiti
- <Prerequisito 1>
- <Prerequisito 2>

## Passi
1. <Step 1>
2. <Step 2>

## Verifica
- <Cosa controllare per confermare esito>

## Rollback
- <Come annullare o mitigare>

## Riferimenti
- <Link a Wiki/KB/Script>

