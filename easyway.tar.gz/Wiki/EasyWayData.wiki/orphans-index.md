---
title: Orphans Index
summary: Pagine della Wiki senza link in ingresso/uscita (degree=0), per collegarle al grafo.
id: ew-orphans-index
status: draft
owner: team-platform
tags: [domain/docs, layer/index, audience/dev, privacy/internal, language/it, docs]
llm:
  include: true
  pii: none
entities: []
updated: '2026-01-09'
---

[[start-here|Home]] > [[domains/docs-governance|Docs]] > [[Layer - Index|Index]]

# Orphans Index

Questa pagina collega le pagine attualmente isolate (degree=0) per ridurre i nodi scollegati nel grafo Obsidian.

Rigenerazione: `pwsh scripts/wiki-orphan-index.ps1` (idempotente).

Totale orfani: 0



