---
tags: [layer/index, domain/docs, PROCESS]
updated: 2026-01-16
owner: team-platform
summary: Workflows, Lifecycles, and Governance - Category index for PROCESS pillar
status: draft
---

[[start-here|Home]] > [[domains/docs-governance|Docs]] > [[Layer - Index|Index]]

# 📁 PROCESS

- Nota per autori: per nuove pagine usare `./_template.md`.


> Workflows, Lifecycles, and Governance

## Categories
- [[Governance]] (0 pages)
- [[Onboarding]] (0 pages)
- [[Testing]] (0 pages)
- [[Deploy]] (0 pages)
- [[Migration]] (0 pages)
- [[CI-CD]] (0 pages)
- [[Checklist]] (0 pages)
- [[Best-Practice]] (0 pages)
- [[DQ]] (0 pages)

---

[⬆️ Back to Knowledge Graph](../../KNOWLEDGE-GRAPH.md)


## Domande a cui risponde
- Che cosa raccoglie questo indice?
- Dove sono i documenti principali collegati?
- Come verificare naming e ancore per questa cartella?
- Dove trovare entità e guide correlate?





