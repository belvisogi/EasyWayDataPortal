---
tags: [layer/index, domain/docs, AUDIENCE]
updated: 2026-01-16
owner: team-platform
summary: Target Reader - Category index for AUDIENCE pillar
status: draft
---

[[start-here|Home]] > [[domains/docs-governance|Docs]] > [[Layer - Index|Index]]

# 📁 AUDIENCE

- Nota per autori: per nuove pagine usare `./_template.md`.


> Target Reader

## Categories
- [[Dev]] (222 pages)
- [[DBA]] (52 pages)
- [[Ops]] (64 pages)
- [[Architect]] (4 pages)
- [[Non-Expert]] (38 pages)

---

[⬆️ Back to Knowledge Graph](../../KNOWLEDGE-GRAPH.md)


## Domande a cui risponde
- Che cosa raccoglie questo indice?
- Dove sono i documenti principali collegati?
- Come verificare naming e ancore per questa cartella?
- Dove trovare entità e guide correlate?





