---
tags: [layer/index, domain/docs, TECH]
updated: 2026-01-16
owner: team-platform
summary: Specific Tools and Technologies - Category index for TECH pillar
status: draft
---

[[start-here|Home]] > [[domains/docs-governance|Docs]] > [[Layer - Index|Index]]

# 📁 TECH

- Nota per autori: per nuove pagine usare `./_template.md`.


> Specific Tools and Technologies

## Categories
- [[Azure]] (0 pages)
- [[Flyway]] (0 pages)
- [[N8n]] (0 pages)
- [[Obsidian]] (0 pages)
- [[PowerShell]] (0 pages)
- [[SQL]] (0 pages)
- [[React]] (0 pages)
- [[Vector-DB]] (0 pages)

---

[⬆️ Back to Knowledge Graph](../../KNOWLEDGE-GRAPH.md)


## Domande a cui risponde
- Che cosa raccoglie questo indice?
- Dove sono i documenti principali collegati?
- Come verificare naming e ancore per questa cartella?
- Dove trovare entità e guide correlate?





