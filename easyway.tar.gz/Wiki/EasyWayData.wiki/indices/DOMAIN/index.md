---
tags: [layer/index, domain/docs, DOMAIN]
updated: 2026-01-16
owner: team-platform
summary: Functional or Business Areas - Category index for DOMAIN pillar
status: draft
---

[[start-here|Home]] > [[domains/docs-governance|Docs]] > [[Layer - Index|Index]]

# 📁 DOMAIN

- Nota per autori: per nuove pagine usare `./_template.md`.


> Functional or Business Areas

## Categories
- [[CAA]] (1 pages)
- [[Control-Plane]] (84 pages)
- [[DataLake]] (15 pages)
- [[DB]] (52 pages)
- [[API]] (2 pages)
- [[UX]] (7 pages)
- [[Security]] (4 pages)
- [[Agents]] (0 pages)
- [[Argos]] (0 pages)
- [[ETL]] (0 pages)
- [[Docs]] (40 pages)
- [[Frontend]] (26 pages)
- [[Architecture]] (1 pages)

---

[⬆️ Back to Knowledge Graph](../../KNOWLEDGE-GRAPH.md)


## Domande a cui risponde
- Che cosa raccoglie questo indice?
- Dove sono i documenti principali collegati?
- Come verificare naming e ancore per questa cartella?
- Dove trovare entità e guide correlate?





