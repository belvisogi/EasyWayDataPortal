---
title: Titolo Pagina (kebab-case-friendly)
summary: Una breve descrizione di 1-2 righe del contenuto.
status: draft
owner: team-docs
tags: ['domain/general', 'layer/reference']
created: 'YYYY-MM-DD'
updated: 'YYYY-MM-DD'
---
# Titolo Pagina

## Domande a cui risponde
- Domanda 1?
- Domanda 2?

## Contenuto
...
