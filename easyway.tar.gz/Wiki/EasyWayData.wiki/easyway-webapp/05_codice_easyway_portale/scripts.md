---
id: ew-easyway-webapp-05-codice-easyway-portale-scripts
title: scripts
tags: [domain/control-plane, layer/reference, audience/dev, audience/ops, privacy/internal, language/it, scripts]
owner: team-platform
summary: 'Documento su scripts.'
status: active
llm:
  include: true
  pii: none
  chunk_hint: 250-400
  redaction: [email, phone]
entities: []
updated: '2026-01-05'
next: TODO - definire next step.
---

[[start-here|Home]] > [[Domain - Control-Plane|Control-Plane]] > [[Layer - Reference|Reference]]

## Domande a cui risponde
- Quali script sono disponibili per sviluppatori e operatori?
- Come eseguire build, test, lint e normalizzazione documentale?
- Come generare manifest, anchors e chunk per gli agenti?
- Dove consultare i report e come interpretarli?








