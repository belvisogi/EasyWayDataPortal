---
id: ew-frontend
title: EasyWay Portal Frontend
summary: Placeholder: architettura, setup e linee guida UI/branding del frontend EasyWay Portal.
status: active
owner: team-api
created: '2025-01-01'
updated: '2025-01-01'
tags: [domain/frontend, layer/reference, audience/dev, privacy/internal, language/it]
title: easyway portal frontend
llm:
  include: true
  pii: none
  chunk_hint: 250-400
  redaction: [email, phone]
entities: []
next: TODO - definire next step.
---


[[start-here|Home]] > [[domains/frontend|frontend]] > [[Layer - Reference|Reference]]

## Domande a cui risponde
- Cosa fa questa pagina?
- Quali sono i prerequisiti?
- Quali passi devo seguire?
- Quali sono gli errori comuni?
- Dove approfondire?










