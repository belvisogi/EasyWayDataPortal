---
id: ew-easyway-webapp-05-codice-easyway-portale-readme
title: readme
tags: [domain/frontend, layer/index, audience/dev, privacy/internal, language/it, readme]
owner: team-platform
summary: 'Documento su readme.'
status: active
llm:
  include: true
  pii: none
  chunk_hint: 250-400
  redaction: [email, phone]
entities: []
updated: '2026-01-05'
next: TODO - definire next step.
---

[[start-here|Home]] > [[domains/frontend|frontend]] > [[Layer - Index|Index]]

## Domande a cui risponde
- Come è organizzata la cartella del codice del portale?
- Dove trovare guide di avvio, policy e script utili?
- Quali passi seguire per contribuire o fare troubleshooting?
- Come verificare consistenza (naming/ancore) e generare i manifest?








