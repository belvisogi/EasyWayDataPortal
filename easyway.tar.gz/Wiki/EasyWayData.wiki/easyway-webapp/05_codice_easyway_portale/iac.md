---
id: ew-iac
title: iac
tags: [domain/control-plane, layer/reference, audience/dev, audience/ops, privacy/internal, language/it, iac]
owner: team-platform
summary: 'Documento su iac.'
status: active
llm:
  include: true
  pii: none
  chunk_hint: 250-400
  redaction: [email, phone]
entities: []
updated: '2026-01-05'
next: TODO - definire next step.
---

[[start-here|Home]] > [[Domain - Control-Plane|Control-Plane]] > [[Layer - Reference|Reference]]

## Domande a cui risponde
- Quali risorse IaC sono previste per il portale?
- Come si struttura il deploy (ambiente, variabili, segreti)?
- Dove trovare policy e naming per componenti cloud?
- Come validare naming/ancore e tracciare i cambiamenti?








