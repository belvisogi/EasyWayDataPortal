---
id: ew-docs
title: docs
tags: [domain/frontend, layer/reference, audience/dev, privacy/internal, language/it, docs]
owner: team-platform
summary: 'Documento su docs.'
status: active
llm:
  include: true
  pii: none
  chunk_hint: 250-400
  redaction: [email, phone]
entities: []
updated: '2026-01-05'
next: TODO - definire next step.
---

[[start-here|Home]] > [[domains/frontend|frontend]] > [[Layer - Reference|Reference]]

## Domande a cui risponde
- Quali documenti compongono l’area “Codice EasyWay Portale”?
- Dove trovare API, frontend, policy e script di supporto?
- Quali sono gli step consigliati per leggere e contribuire al codice?
- Come verificare naming, anchor e manifest per questa sezione?








