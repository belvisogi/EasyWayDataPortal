---
id: ew-step-2-—-struttura-src-e-primi-file
title: STEP 2 — Struttura src e primi file (LEGACY)
tags: [domain/control-plane, layer/howto, audience/dev, privacy/internal, language/it, api, structure, status/deprecated]
owner: team-platform
summary: 'Pagina legacy mantenuta solo per compatibilità: usa la versione canonica step-2-struttura-src-e-primi-file.md.'
status: deprecated
llm:
  include: false
  pii: none
  chunk_hint: 250-400
  redaction: [email, phone]
canonical: ./step-2-struttura-src-e-primi-file.md
entities: []
updated: '2026-01-10'
next: ./step-2-struttura-src-e-primi-file.md
---
[[start-here|Home]] > [[Domain - Control-Plane|Control-Plane]] > [[Layer - Howto|Howto]]

> **Questa pagina è legacy / non canonica.**  
> Usa la versione aggiornata e indicizzata per gli agent:
>
> - [STEP 2 — Struttura src e primi file (canonico)](./step-2-struttura-src-e-primi-file.md)

