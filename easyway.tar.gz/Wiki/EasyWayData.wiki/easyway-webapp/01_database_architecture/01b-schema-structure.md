---
id: ew-01b-schema-structure
title: 01b schema structure
tags: [domain/db, layer/spec, audience/dev, audience/dba, privacy/internal, language/it, schema]
owner: team-platform
summary: 'Documento su 01b schema structure.'
status: active
llm:
  include: true
  pii: none
  chunk_hint: 250-400
  redaction: [email, phone]
entities: []
updated: '2026-01-05'
next: TODO - definire next step.
---


[[start-here|Home]] > [[domains/db|db]] > [[Layer - Spec|Spec]]

## Domande a cui risponde
- Quali sono le tabelle e gli schemi principali?
- Dove sono le convenzioni di naming e i collegamenti a programmability?
- Quali passi minimi per aggiornare struttura e indici?
- Dove trovare le entità correlate nel dizionario?









