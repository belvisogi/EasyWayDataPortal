---
id: ew-db-table-portal-user-notification-settings
title: db-table-portal-user-notification-settings
summary: Preferenze notifiche per utente (canali, opt-in/out, regole).
status: draft
owner: team-data
tags: [domain/db, layer/reference, audience/dev, audience/dba, privacy/internal, language/it]
llm:
  include: true
  pii: none
  chunk_hint: 250-400
  redaction: [email, phone]
entities: []
updated: '2026-01-06'
next: Collegare a SUBSCRIPTION e SP di notifiche.
---

[[start-here|Home]] > [[domains/db|db]] > [[Layer - Reference|Reference]]

# PORTAL.USER_NOTIFICATION_SETTINGS — User notification settings

## Contesto
- Source-of-truth DB: `db/flyway/sql/`.

## Scopo
- TODO: descrivere quali preferenze vengono salvate e come sono applicate.


