---
id: ew-db-table-portal-masking-metadata
title: db-table-portal-masking-metadata
summary: Metadati di masking per campi sensibili (policy applicabili per colonna).
status: draft
owner: team-data
tags: [domain/db, layer/reference, audience/dev, audience/dba, privacy/internal, language/it, security]
llm:
  include: true
  pii: none
  chunk_hint: 250-400
  redaction: [email, phone]
entities: []
updated: '2026-01-06'
next: Collegare alle regole di masking e ai vincoli security.
---

[[start-here|Home]] > [[domains/db|db]] > [[Layer - Reference|Reference]]

# PORTAL.MASKING_METADATA — Masking metadata

## Contesto
- Source-of-truth DB: `db/flyway/sql/` (vedi `easyway-webapp/01_database_architecture/ddl-inventory.md`).

## Scopo
- TODO: descrivere come viene usata per masking dinamico/controlli a runtime.


